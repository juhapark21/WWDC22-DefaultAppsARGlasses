//
//  File.swift
//  WWDC22
//
//  Created by Juha Park on 4/5/22.
//

import Combine
import Foundation
import RealityKit
import SwiftUI

extension Entity {
    // Entity shaking function modified from RealityUI framework by Max Cobb  https://github.com/maxxfrazer/RealityUI/blob/main/Sources/RealityUI/RUIAnimations.swift
    func shake(by quat: simd_quatf, period: TimeInterval, times: Int, completion: (() -> Void)? = nil) {
        let rockBit = matrix_multiply(
            transform.matrix,
            Transform(scale: .one, rotation: quat, translation: .zero).matrix
        )
        move(to: rockBit, relativeTo: parent, duration: period / 2, timingFunction: .easeIn)
        var shakeCancellable: Cancellable!
        shakeCancellable = scene?.subscribe(to: AnimationEvents.PlaybackCompleted.self, on: self, { _ in
            shakeCancellable.cancel()
            self.shakePrivate(
                by: simd_quatf(angle: -quat.angle * 2, axis: quat.axis),
                period: period,
                remaining: times == -1 ? times : max(times * 2 - 1, 0),
                completion: completion
            )
        })
    }

    private func shakePrivate(
        by quat: simd_quatf, period: TimeInterval,
        remaining: Int, completion: (() -> Void)? = nil
    ) {
        var applyQuat: simd_quatf!
        if remaining != 0 {
            applyQuat = quat
        } else {
            applyQuat = simd_quatf(angle: quat.angle / 2, axis: quat.axis)
        }
        let rockBit = matrix_multiply(
            transform.matrix,
            Transform(scale: .one, rotation: applyQuat, translation: .zero).matrix
        )
        move(
            to: rockBit, relativeTo: parent,
            duration: remaining == 0 ? period / 2 : period,
            timingFunction: remaining == 0 ? .easeOut : .linear
        )
        var shakeCancellable: Cancellable!
        shakeCancellable = scene?.subscribe(to: AnimationEvents.PlaybackCompleted.self, on: self, { _ in
            shakeCancellable.cancel()
            if remaining != 0 {
                let newQuat = simd_quatf(angle: -quat.angle, axis: quat.axis)
                self.shakePrivate(by: newQuat, period: period, remaining: remaining - 1, completion: completion)
            } else {
                completion?()
            }
        })
    }
}

class EntityManager {
    public func loadModel(usdzName: String) -> Entity {
        // Loads a usdz model (synchronously) and generates a default cube if resource is not found
        var loadedModel: Entity {
            if let theURL = Bundle.main.url(forResource: usdzName, withExtension: "usdz") {
                do {
                    let model = try Entity.loadModel(contentsOf: theURL)
                    return model
                } catch {
                    print("couldn't load model with url \(usdzName).usdz: generating default cube")

                    let mesh = MeshResource.generateBox(size: 0.1)
                    let entity = ModelEntity(mesh: mesh)

                    return entity
                }
            } else {
                print("url \(usdzName).usdz not found: generating default cube")
                let mesh = MeshResource.generateBox(size: 0.1)
                let entity = ModelEntity(mesh: mesh)

                return entity
            }
        }

        return loadedModel
    }
}

// Makes a default (simple) text entity
func textEntityWithName(text: String, size: CGFloat = 0.015, textColor: UIColor = UIColor(red: 1.00, green: 0.84, blue: 0.38, alpha: 1.00), weight: UIFont.Weight = .light, opacity: CGFloat = 1, containerFrame: CGRect = .zero) -> ModelEntity {
    let textMesh = MeshResource.generateText(text, extrusionDepth: 0.0005, font: .systemFont(ofSize: size, weight: .thin), containerFrame: containerFrame, alignment: .center, lineBreakMode: .byWordWrapping)
    var textMaterial = SimpleMaterial(color: textColor, isMetallic: false)
    textMaterial.color = .init(tint: textColor.withAlphaComponent(opacity), texture: nil)
    let textModel = ModelEntity(mesh: textMesh, materials: [textMaterial])

    return textModel
}
