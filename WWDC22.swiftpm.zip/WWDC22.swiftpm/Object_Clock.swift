//
//  File.swift
//  WWDC22
//
//  Created by Juha Park on 4/6/22.
//

import Combine
import RealityKit
import SwiftUI

public class ClockTimerObject: CustomObject {
    var faceModelEntity = ModelEntity()
    var myMode: String = ""

    var display: String = "12:00 PM"
    var timerTime = 60
    var timerStarted = false
    var timer = Timer()

    var hasAlreadyReachedZero = false
    public var alarmIsRinging = false

    public var originalOrientation: simd_quatf = simd_quatf(real: 1.0, imag: SIMD3<Float>(0.0, 0.0, 0.0))

    var base = ModelEntity()
    // "Change mode" Button
    var button = EntityManager().loadModel(usdzName: "redButton") as! ModelEntity
    var buttonText = EntityManager().loadModel(usdzName: "redButtonText") as! ModelEntity
    var buttonWrapper = Entity()
    let font = UIFont(name: "AppleSDGothicNeo-Regular", size: 0.015)
    // Time controls (up & down 1min)
    var upButton = EntityManager().loadModel(usdzName: "upTimer")
    var downButton = EntityManager().loadModel(usdzName: "downTimer")

    // Reset buttons (button that isn't always there)
    let resetButton = EntityManager().loadModel(usdzName: "resetButton")
    let resetButtonText = textEntityWithName(text: "Reset")
    let resetButtonWrapper = Entity()

    public required init() {
        super.init()
        // Shell and base
        let clockShell = EntityManager().loadModel(usdzName: "clockShell")
        base = EntityManager().loadModel(usdzName: "baseTime") as! ModelEntity

        // Button (for changing the mode)
        buttonText.position.y += 0.035
        buttonText.position.z += 0.025

        buttonWrapper.addChild(button)
        buttonWrapper.addChild(buttonText)

        button.name = "Clock_Button"
        buttonText.name = "Clock_ButtonText"

        // Button (for resetting time)
        resetButtonText.position.y = 0.1305
        resetButtonText.position.z = 0.006
        resetButtonText.position.x = -0.02

        resetButtonWrapper.addChild(resetButton)
        resetButtonWrapper.addChild(resetButtonText)

        // Clock/Timer face
        let faceMaterial = SimpleMaterial(color: .black, isMetallic: true)
        let faceMesh = MeshResource.generateText(display, extrusionDepth: 0.002, font: font ?? .systemFont(ofSize: 0.015), containerFrame: .zero, alignment: .center, lineBreakMode: .byClipping)
        faceModelEntity = ModelEntity(mesh: faceMesh, materials: [faceMaterial])

        faceModelEntity.position.z = 0.02
        faceModelEntity.position.y = 0.05
        faceModelEntity.position.x = -0.03

        // Naming
        base.name = "Clock_Base"

        upButton.name = "Clock_UpButton"
        downButton.name = "Clock_DownButton"

        resetButtonWrapper.name = "Clock_ResetButton"
        resetButton.name = "Clock_ResetButton"
        resetButtonText.name = "Clock_ResetButtonText"

        resetButtonWrapper.generateCollisionShapes(recursive: true)

        // Add to model
        addChild(clockShell)
        addChild(base)
        addChild(buttonWrapper)
        addChild(faceModelEntity)
        addChild(upButton)
        addChild(downButton)
        addChild(resetButtonWrapper)

        makeInfoView(text: "This is Clock. Tap on the main button to change modes. On the timer, use the arrow buttons to adjust the time left. Tap anywhere on the clock to stop the alarm once it reaches zero.")
        infoViewModel.name = "Clock_InfoViewModel"
        infoViewText.name = "Clock_InfoViewText"
        infoViewWrapper.name = "Clock_InfoViewWrapper"

        myMode = "clock"

        generateCollisionShapes(recursive: true)

        // Hide/Show
        upButton.isEnabled = false
        downButton.isEnabled = false

        resetButtonWrapper.isEnabled = false
        
        originalOrientation = orientation

        start()
    }

    func updateLooks() {
        //Change the mode
        if myMode == "clock" {
            let newBase = EntityManager().loadModel(usdzName: "baseTime") as! ModelEntity
            base.model?.materials = newBase.model!.materials

            let newButton = EntityManager().loadModel(usdzName: "redButton") as! ModelEntity
            let newButtonText = EntityManager().loadModel(usdzName: "redButtonText") as! ModelEntity
            button.model = newButton.model
            buttonText.children[0] = newButtonText

            upButton.isEnabled = false
            downButton.isEnabled = false

            faceModelEntity.position.z = 0.02
            faceModelEntity.position.y = 0.05
            faceModelEntity.position.x = -0.03

            myMode = "clock"

        } else if myMode == "timer" {
            let newBase = EntityManager().loadModel(usdzName: "baseTimer") as! ModelEntity
            base.model?.materials = newBase.model!.materials

            let newButton = EntityManager().loadModel(usdzName: "greenButton") as! ModelEntity
            let newButtonText = EntityManager().loadModel(usdzName: "greenButtonText") as! ModelEntity
            button.model = newButton.model
            buttonText.children[0] = newButtonText

            upButton.isEnabled = true
            downButton.isEnabled = true

            faceModelEntity.position.z = 0.02
            faceModelEntity.position.y = 0.05
            faceModelEntity.position.x = -0.02

            myMode = "timer"
            timerStarted = true
        }
        timer.fire()
    }

    func drawDisplay() {
        // Update what's in the "display" variable to show on the AR model
        let updatedClockFaceMesh = MeshResource.generateText(display, extrusionDepth: 0.002, font: font ?? .systemFont(ofSize: 0.015), containerFrame: .zero, alignment: .center, lineBreakMode: .byClipping)

        faceModelEntity.model?.mesh = updatedClockFaceMesh
    }

    public func start() {
        let calendar = Calendar.autoupdatingCurrent
        var minute = calendar.component(.minute, from: Date()) - 1
        var blink = " "

        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [self] _ in
            // Code here executes every second
            if myMode == "clock" {
                //Update w/ the current time
                let min = Calendar.autoupdatingCurrent.component(.minute, from: Date())
                var hr = Calendar.autoupdatingCurrent.component(.hour, from: Date())
                var displayhr = String(hr)
                var displaymin = String(min)
                var ampm = "AM"

                if Calendar.autoupdatingCurrent.component(.minute, from: Date()) != minute {
                    // The minute changed

                    // Change time like 14:20 to 2:20 PM
                    if hr > 12 {
                        ampm = "PM"
                        hr = hr - 12
                        displayhr = String(hr)
                    } else {
                        ampm = "AM"
                    }

                    // Add 0 in front if hr is single digits
                    if hr < 10 {
                        displayhr = "0\(hr)"
                    }

                    // Add 0 in front if min is single digits
                    if min < 10 {
                        displaymin = "0\(min)"
                    }

                    // Blink
                    if blink == ":" {
                        blink = " "
                    } else {
                        blink = ":"
                    }

                    display = "\(displayhr)\(blink)\(displaymin) \(ampm)"

                    minute = Calendar.autoupdatingCurrent.component(.minute, from: Date())
                } else {
                    // Still update blink even if minute is not changed
                    if blink == ":" {
                        blink = " "
                    } else {
                        blink = ":"
                    }

                    var displayhr = String(hr)
                    var displaymin = String(min)
                    var ampm = "AM"

                    // Change hrs like 14:20 to 2:20 PM
                    if hr > 12 {
                        ampm = "PM"
                        hr = hr - 12
                        displayhr = String(hr)
                    } else {
                        ampm = "AM"
                    }

                    // Add 0 in front if hr is single digits
                    if hr < 10 {
                        displayhr = "0\(hr)"
                    }

                    // Add 0 in front if min is single digits
                    if min < 10 {
                        displaymin = "0\(min)"
                    }

                    display = "\(displayhr)\(blink)\(displaymin) \(ampm)"
                }
            } else {
                // Update timer (time left)
                let time = timerTime.quotientAndRemainder(dividingBy: 60)

                var displayMins = String(time.quotient)
                var displaySecs = String(time.remainder)

                if displayMins.count == 1 {
                    displayMins = "0\(displayMins)"
                }
                if displaySecs.count == 1 {
                    displaySecs = "0\(displaySecs)"
                }

                display = "\(displayMins):\(displaySecs)"
            }
            if timerStarted {
                if timerTime > 0 {
                    timerTime -= 1
                } else {
                    // Timer reached zero
                    // If mode is clock switch it back to timer
                    if myMode == "clock" {
                        myMode = "timer"
                        updateLooks()
                    }

                    if !hasAlreadyReachedZero {
                        // Only need to do once when timer reaches 0

                        // Have object play sound
                        AudioManager().playSpatialAudio(fileName: "AlarmClockSound.mp3", entity: self)

                        alarmIsRinging = true

                        hasAlreadyReachedZero = true
                    }

                    // Needs to be repeated every second
                    //Shake timer
                    self.shake(by: simd_quatf(angle: .pi / 30, axis: [0, 0, 1]), period: 0.1, times: 3) {
                        //Shaking done
                        self.orientation = self.originalOrientation
                    }
                    
                }
            }
            if !hasAlreadyReachedZero {
                // If timer has not already reached 0 update
                drawDisplay()
            }
        }
    }

    public func hittest(tappedEntity: Entity) -> Bool {
        // Returns whether or not tapped entity was an interactive object in Clock

        if !tappedEntity.name.contains("Photo") && !tappedEntity.name.contains("Weather") {
            // It is a clock/timer object
            if alarmIsRinging {
                // This action will override all others (no other buttons will be pressed while the alarm is ringing).
                // Stop the alarm!
                AudioManager().stopSpatialAudio()
                alarmIsRinging = false
                hasAlreadyReachedZero = false
                timer.invalidate()
                resetButtonWrapper.isEnabled = true
                return true
            }
        }

        if tappedEntity.name == "Text" || tappedEntity.name == "Button" || tappedEntity.name == "Clock_Button" || tappedEntity.name == "Clock_ButtonText" {
            // Tapped mode change button
            if myMode == "clock" {
                myMode = "timer"
            } else if myMode == "timer" {
                myMode = "clock"
            } else {
                // uhh.?
                print("mode either not clock or timer: \(myMode)")
            }

            updateLooks()
            return true
        } else if tappedEntity.name == "Clock_UpButton" {
            // Increase by 1min
            // 60 mins max
            if timerTime < 60 * 60 + 60 {
                timerTime += 60
            } else if timerTime < 60 * 60 {
                timerTime = 60 * 60
            }

            let time = timerTime.quotientAndRemainder(dividingBy: 60)
            var displayMins = String(time.quotient)
            var displaySecs = String(time.remainder)
            if displayMins.count < 2 {
                displayMins = "0\(displayMins)"
            }
            if displaySecs.count < 2 {
                displaySecs = "0\(displaySecs)"
            }

            display = "\(displayMins):\(displaySecs)"
            drawDisplay()
            return true
        } else if tappedEntity.name == "Clock_DownButton" {
            // Decrease by 1min
            // 0 secs minimum
            if timerTime - 60 > 0 {
                timerTime -= 60
            } else if timerTime > 0 {
                timerTime = 0
            }

            let time = timerTime.quotientAndRemainder(dividingBy: 60)
            var displayMins = String(time.quotient)
            var displaySecs = String(time.remainder)
            if displayMins.count < 2 {
                displayMins = "0\(displayMins)"
            }
            if displaySecs.count < 2 {
                displaySecs = "0\(displaySecs)"
            }
            display = "\(displayMins):\(displaySecs)"
            drawDisplay()

            return true
        } else if tappedEntity.name == "Clock_ResetButton" || tappedEntity.name == "Clock_ResetButtonText" {
            // Reset back to 1min
            timerTime = 60
            start()
            resetButtonWrapper.isEnabled = false
        }
        return false
    }
}
