//
//  File.swift
//  WWDC22
//
//  Created by Juha Park on 4/10/22.
//

import UIKit
import RealityKit

//Custom object class that all other models (objects) inherit
public class CustomObject: Entity, HasCollision {
    //Functions and variables that are used across all the objects are here.
    public var entityGestureRecognizers: [UIGestureRecognizer] = []
    
    public var isInEditMode: Bool = true
    public var isInBox: Bool = true
    
    var infoViewModel = EntityManager().loadModel(usdzName: "speechBubble") //ModelEntity(mesh: MeshResource.generateBox(width: 0.1, height: 0.08, depth: 0.0002), materials: [SimpleMaterial.init(color: .white, roughness: 1, isMetallic: false)])
    var infoViewText = ModelEntity()
    let infoViewWrapper = Entity()
        
    required init() {
        super.init()
    }
    
    func makeInfoView(text: String) {
        //Generate and place an info view above a custom object.
        infoViewText = textEntityWithName(text: text, size: 0.007, textColor: .black, weight: .medium, containerFrame: .init(x: Double(infoViewModel.position.x), y: Double(infoViewModel.position.y), width: 0.1, height: 0.2))
        
        infoViewWrapper.addChild(infoViewModel)
        infoViewWrapper.addChild(infoViewText)
        
        infoViewText.position.x = -0.05
        infoViewText.position.y = -0.01
        
        infoViewModel.position.y = 0.06
        infoViewModel.scale = [1, 1, 0.01]
        
        infoViewWrapper.position.y = 0.17
        infoViewWrapper.position.z = -0.01
        
        self.addChild(infoViewWrapper)
        self.generateCollisionShapes(recursive: true)
        toggleInfoView(show: false)
    }
    
    func toggleInfoView(show: Bool) {
        //Show or hide the info view
        if show {
            //show
            infoViewWrapper.isEnabled = true
        } else {
            //hide
            infoViewWrapper.isEnabled = false
        }
    }
    
    public func toggleEditMode() {
        //Change edit mode and shake object slightly afterwards
        isInEditMode.toggle()
        self.shake(by: simd_quatf(angle: .pi / 100, axis: [0, 0, 1]), period: 0.05, times: 2)
    }
}
