//
//  File.swift
//  WWDC22
//
//  Created by Juha Park on 4/8/22.
//

import AVFoundation
import RealityKit

var audioPlayer: AVAudioPlayer?

var audioController: AudioPlaybackController!

class AudioManager {
    //https://www.hackingwithswift.com/example-code/media/how-to-play-sounds-using-avaudioplayer
    //https://ethansaadia.medium.com/immersive-audio-in-realitykit-b3748c0a4319 

    func playSpatialAudio(fileName: String, entity: Entity) {
        let audioFilePath = Bundle.main.path(forResource: fileName, ofType: nil)!

        do {
            let resource = try AudioFileResource.load(contentsOf: URL(fileURLWithPath: audioFilePath), inputMode: .spatial, loadingStrategy: .preload, shouldLoop: true)

            audioController = entity.prepareAudio(resource)
            audioController.play()

        } catch {
            print("Error loading audio file with name \(fileName)")
        }
    }
    
    func stopSpatialAudio() {
        audioController.stop()
    }
}
