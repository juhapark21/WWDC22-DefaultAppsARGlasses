//
//  File.swift
//  WWDC22
//
//  Created by Juha Park on 4/6/22.
//


import Foundation
import SwiftUI

struct TutorialOverlayView: View {
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                //Colors from https://2colors.colorion.co/, https://www.uicolor.io/
                Color(UIColor(red: 0.54, green: 0.67, blue: 0.90, alpha: 1.00))
                VStack {
                    Spacer()
                    Group {
                        Text("Hello 👋!")
                            .font(.system(size: 50, weight: .heavy, design: .default))
                            .foregroundColor(Color.init(hex: "#FEFEFE"))
                            .padding()
                        Spacer()
                            .frame(height: 20)
                        Text("My name is Juha, and I'm 14.")
                            .font(.title)
                            .fontWeight(.medium)
                            .foregroundColor(Color.init(hex: "#FEFEFE"))
                            .frame(width: geometry.size.width * 0.8)
                        Text("This is my WWDC submission, Default Apps with AR Glasses.")
                            .font(.title)
                            .fontWeight(.medium)
                            .foregroundColor(Color.init(hex: "#FEFEFE"))
                            .frame(width: geometry.size.width * 0.8)
                        Text("It is an interactive scene where you can play around with desktop visualizations of 3 different apps in AR.")
                            .font(.title)
                            .fontWeight(.medium)
                            .foregroundColor(Color.init(hex: "#FEFEFE"))
                            .multilineTextAlignment(.center)
                            .frame(width: geometry.size.width * 0.8)
                            .padding()
                        Spacer()
                        Spacer()
                            .frame(height: 40)
                        Text("Tap anywhere to continue")
                            .font(.largeTitle)
                            .fontWeight(.light)
                            .foregroundColor(Color.init(hex: "#f5fff2"))
                            .padding()
                    }
                    Spacer()
                }
            }
        }
    }
}

extension Color {
    //https://stackoverflow.com/a/56874327/15372665
    init(hex: String, alpha: Double = 1) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (r, g, b) = ((int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (r, g, b) = (int >> 16, int >> 8 & 0xFF, int & 0xFF)
        default:
            (r, g, b) = (1, 1, 0)
        }

        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: alpha
        )
    }
}
