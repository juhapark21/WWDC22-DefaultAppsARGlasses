//
//  ContentView.swift
//  WWDC22
//
//  Created by Juha Park on 4/5/22.
//

// Note: please disable the SwiftUI preview before starting. Even without the preview, it still might take a while to load.  

import ARKit
import RealityKit
import SwiftUI

var arView = ARView()

var isPlaced = false

var photoFrame = FramedPhotoObject()
var weatherObject = WeatherObject(object: .sunny)
var clockObject = ClockTimerObject()
var toybox = EntityManager().loadModel(usdzName: "toybox")

func nameObjects() {
    clockObject.name = "Clock"
    photoFrame.name = "Photos"
    weatherObject.name = "Weather"
    toybox.name = "Toybox"
}

// Tutorial
var lockHasBeenToggled = false
var boxHasBeenToggled = false
var helpHasBeenToggled = false

// Coordinator and AR struct from https://www.youtube.com/watch?v=cT8y7fNEMuw
class ARViewCoordinator: NSObject, ARSessionDelegate {
    var arViewWrapper: ARViewWrapper
    @Binding var alertViewText: String
    @Binding var isShowingHelpView: Bool
    @Binding var tutorialStage: Int

    init(arViewWrapper: ARViewWrapper, alertViewText: Binding<String>, isShowingHelpView: Binding<Bool>, tutorialStage: Binding<Int>) {
        self.arViewWrapper = arViewWrapper
        _alertViewText = alertViewText
        _isShowingHelpView = isShowingHelpView
        _tutorialStage = tutorialStage
    }
}

// View wrapper for SwiftUI
struct ARViewWrapper: UIViewRepresentable {
    @Binding var alertViewText: String
    @Binding var isShowingHelpView: Bool
    @Binding var tutorialStage: Int
    typealias UIViewType = ARView

    func makeCoordinator() -> ARViewCoordinator {
        return ARViewCoordinator(arViewWrapper: self, alertViewText: $alertViewText, isShowingHelpView: $isShowingHelpView, tutorialStage: $tutorialStage)
    }

    func makeUIView(context: Context) -> ARView {
        // Set up ARView
        arView = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: true)
        // People occlusion had performance issues :(
        // arView.environment.sceneUnderstanding.options = .occlusion
        arView.enablePlacement()
        nameObjects()
        arView.session.delegate = context.coordinator

        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {
    }
}

extension ARView {
    func enablePlacement() {
        // Set up gesture handling (tap gesture, long press, and triple (multi) tap)
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap(recognizer:)))
        let longPressGestureRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(recognizer:)))
        let multiTapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleMultiTap(_:)))
        multiTapGestureRecognizer.numberOfTouchesRequired = 3

        addGestureRecognizer(tapGestureRecognizer)
        addGestureRecognizer(longPressGestureRecognizer)
        addGestureRecognizer(multiTapGestureRecognizer)
    }

    func addGestures(entity: CustomObject) {
        var name = "GESTURERECOGNIZER"

        if entity is ClockTimerObject {
            name = "CLOCKGESTURE"
        } else if entity is WeatherObject {
            name = "WEATHERGESTURE"
        } else if entity is FramedPhotoObject {
            name = "PHOTOGESTURE"
        }

        installGestures(for: entity).forEach { gestureRecognizer in
            gestureRecognizer.name = name
            gestureRecognizer.addTarget(self, action: #selector(handleGesture(_:)))
            entity.entityGestureRecognizers.append(gestureRecognizer)
        }
    }

    // https://stackoverflow.com/a/69139991/15372665
    func removeGestures(entity: CustomObject) {
        for recognizer in entity.entityGestureRecognizers {
            guard let recognizerIndex = gestureRecognizers?.firstIndex(of: recognizer) else {
                print("error: recognizer index not found")
                return
            }

            gestureRecognizers?.remove(at: recognizerIndex)
            entity.entityGestureRecognizers.removeAll()
        }
    }

    @objc func handleTap(recognizer: UITapGestureRecognizer) {
        guard let coordinator = session.delegate as? ARViewCoordinator else {
            print("Error obtaining coordinator")
            return
        }

        let location = recognizer.location(in: self)

        let results = raycast(from: location, allowing: .estimatedPlane, alignment: .horizontal)

        if results.first != nil {
            if !isPlaced {
                // Place everything! (since it hasn't been placed yet)
                let anchorEntity = AnchorEntity(plane: .horizontal)

                anchorEntity.addChild(toybox)
                toybox.scale.x = 2 / 3
                toybox.scale.y = 2 / 3
                toybox.scale.z = 2 / 3

                photoFrame.scale = [0.5, 0.5, 0.5]
                photoFrame.position.y = 0.02
                anchorEntity.addChild(photoFrame)

                weatherObject.scale = [0.5, 0.5, 0.5]
                weatherObject.position.y = 0.02
                weatherObject.position.z = -0.03
                weatherObject.position.x = 0.06
                anchorEntity.addChild(weatherObject)

                clockObject.scale = [0.5, 0.5, 0.5]
                clockObject.position.y = 0.02
                clockObject.position.z = 0.04
                clockObject.position.x = -0.03
                anchorEntity.addChild(clockObject)

                addGestures(entity: photoFrame)
                addGestures(entity: weatherObject)
                addGestures(entity: clockObject)

                scene.addAnchor(anchorEntity)

                // Added objects
                // TUTORIAL: 2
                
                if coordinator.tutorialStage == 1 {
                    coordinator.tutorialStage += 1
                    //Move on to 2
                    coordinator.alertViewText = "Great! Now, drag the objects out to place it wherever you want and rotate it however you want. The box will disappear afterwards but you can always bring it back by tapping with three fingers at once."
                }

                // After anchor is added to scene, animate Weather
                weatherObject.animate(object: .sunny)
                let allObjects = WeatherCase.allCases
                var i = 0
                Timer.scheduledTimer(withTimeInterval: 15, repeats: true) { _ in
                    // Every 15secs change to next model
                    i += 1
                    if i > allObjects.count - 1 {
                        i = 0
                    }
                    weatherObject.changeModel(to: allObjects[i])
                }
            } else {
                // If everything has been placed already, check if the tap was on any entities
                if let tappedEntity = entity(at: location) {
                    // See if the entity is a button - and if so, execute the correct actions
                    if !clockObject.hittest(tappedEntity: tappedEntity) {
                        // If not clock then maybe weather?
                        if !weatherObject.hittest(tappedEntity: tappedEntity) {
                            // If not weather then probably photo?
                            if !photoFrame.hittest(tappedEntity: tappedEntity) {
                                // Not any interactive entity :(
                            }
                        }
                    }
                } else {
                    // No entity was tapped :(
                }
            }

            isPlaced = true
        } else {
            if !isPlaced {
                // If the objects haven't been placed yet and no surface was detected, display and print alert
                let beforeText = coordinator.alertViewText
                print("No surface detected - please move around device")
                coordinator.alertViewText = "No surface detected - please move around device"
                // Change back to original text after 2 seconds
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    if coordinator.tutorialStage == 1 {
                        coordinator.alertViewText = beforeText
                    }
                }
            }
        }
    }

    @objc private func handleMultiTap(_ recognizer: UITapGestureRecognizer) {
        switch recognizer.state {
        case .began: break
        case .ended:
            toybox.isEnabled.toggle()

        case .possible: break
        case .changed: break
        case .cancelled: break
        case .failed: break
        @unknown default: break
        }
    }

    @objc private func handleGesture(_ recognizer: UIGestureRecognizer) {
        guard let translationGesture = recognizer as? EntityTranslationGestureRecognizer else { return }

        let objectBeingHandled = translationGesture.entity

        switch translationGesture.state {
        case .began:
            objectBeingHandled?.scale = [0.5, 0.5, 0.5]
            objectBeingHandled?.position.y = 0.02
        case .ended:
            guard let position = objectBeingHandled?.position else { return }
            let toyp = toybox.position

            if let customObject = objectBeingHandled as? CustomObject {
                customObject.isInBox = false
            }

            objectBeingHandled?.scale = [1, 1, 1]
            objectBeingHandled?.position.y = 0

            if toybox.isEnabled {
                if position.x < toyp.x + 0.14 && position.x > toyp.x - 0.14 {
                    // Object is inside x range of box
                    if position.z < toyp.z + 0.14 && position.z > toyp.z - 0.14 {
                        // Object is also inside z range of box
                        if position.y < toyp.y + 0.15 && position.y >= toyp.y {
                            // Object is inside the box
                            if let customObject = objectBeingHandled as? CustomObject {
                                customObject.isInBox = false
                            }
                            objectBeingHandled?.scale = [0.5, 0.5, 0.5]
                            objectBeingHandled?.position.y = 0.02
                        }
                    }
                }
            }

            if let customObject = objectBeingHandled as? CustomObject {
                if !customObject.isInBox {
                    checkIfBoxIsEmpty()
                }
            }

            // Change default orientation for clock/timer (unless it's ringing)
            if objectBeingHandled!.name.contains("Clock") {
                // It is a clock/timer object
                if !clockObject.alarmIsRinging {
                    // It's not ringing
                    // Set orientation
                    clockObject.originalOrientation =  objectBeingHandled!.orientation
                }
            }

        default:
            break
        }
    }

    private func checkIfBoxIsEmpty() {
        if !photoFrame.isInBox && !weatherObject.isInBox && !clockObject.isInBox && toybox.isEnabled == true {
            if !boxHasBeenToggled {
                // Box is empty
                poof()
                boxHasBeenToggled = true
            }
        }
    }

    private func poof() {
        // Disappear!
        guard let coordinator = session.delegate as? ARViewCoordinator else {
            print("Error obtaining coordinator")
            return
        }

        toybox.isEnabled = false

        // TUTORIAL: 3
        if coordinator.tutorialStage == 2 {
            coordinator.tutorialStage += 1
            //Move on to 3
            coordinator.alertViewText = "If you want to lock or unlock on object's position, long press on it for 1-2 seconds. If it is successful, the object will shake slightly; it usually works best when the iPad is not moving. When an object is locked, it will not be able to move or rotate until it's unlocked again."
            DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
                // TUTORIAL: 4
                if coordinator.tutorialStage == 3 {
                    coordinator.tutorialStage += 1
                    //Move on to 4
                    coordinator.alertViewText = "To see how to interact with the objects, press the help button on the top right. Press the button again to hide it."
                }
            }
        }
    }

    @objc func handleLongPress(recognizer: UILongPressGestureRecognizer) {
        guard let coordinator = session.delegate as? ARViewCoordinator else {
            print("Error obtaining coordinator")
            return
        }

        switch recognizer.state {
        case .began: break
        case .ended:
            let location = recognizer.location(in: self)

            if let tappedEntity = entity(at: location) {
                // Long press was on an object

                let before = lockHasBeenToggled

                lockHasBeenToggled = true

                if tappedEntity.name.contains("Clock") {
                    // Clock was long pressed
                    clockObject.toggleEditMode()
                    if clockObject.isInEditMode {
                        // Enable gestures
                        addGestures(entity: clockObject)
                    } else {
                        // Disable gestures
                        removeGestures(entity: clockObject)
                    }
                } else if tappedEntity.name.contains("Photo") {
                    // Photo was long pressed
                    photoFrame.toggleEditMode()
                    if photoFrame.isInEditMode {
                        // Enable gestures
                        addGestures(entity: photoFrame)
                    } else {
                        // Disable gestures
                        removeGestures(entity: photoFrame)
                    }
                } else if tappedEntity.name.contains("Weather") {
                    // Weather was long pressed
                    weatherObject.toggleEditMode()
                    if weatherObject.isInEditMode {
                        // Enable gestures
                        addGestures(entity: weatherObject)
                    } else {
                        // Disable gestures
                        removeGestures(entity: weatherObject)
                    }
                } else {
                    // Not a custom entity..??
                    lockHasBeenToggled = false
                }
            }
        case .possible: break
        case .changed: break
        case .cancelled: break
        case .failed: break
        @unknown default: break
        }
    }

    func showOrHideHelpView() {
        // Called when the SwiftUI (help) button is pressed
        guard let coordinator = session.delegate as? ARViewCoordinator else {
            print("Error obtaining coordinator")
            return
        }

        if coordinator.isShowingHelpView {
            // Show
            photoFrame.toggleInfoView(show: true)
            weatherObject.toggleInfoView(show: true)
            clockObject.toggleInfoView(show: true)
        } else {
            // Hide
            photoFrame.toggleInfoView(show: false)
            weatherObject.toggleInfoView(show: false)
            clockObject.toggleInfoView(show: false)
        }

        if coordinator.isShowingHelpView && !helpHasBeenToggled {
            // First time turning it on
            // TUTORIAL: 5
            if coordinator.tutorialStage == 4 {
                coordinator.tutorialStage += 1
                //Move on to 5
                coordinator.alertViewText = "Yay! Now you know all the basics; you can now play around with the objects however you want. Have fun!"
                DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
                    coordinator.alertViewText.removeAll()
                }
            }
            helpHasBeenToggled = true
        }
    }
}

struct ContentView: View {
    @State private var isShowingTutorialView = true
    @State private var tutorialStage = 1
    // Alert view text for tutorial messages and warnings (alerts)
    // TUTORIAL: 1
    @State private var alertViewText = "To start, tap on an available surface to place the objects."
    @State private var isShowingHelpView = false

    @State var size: CGFloat = 0.8

    var repeatingAnimation: Animation {
        // https://stackoverflow.com/a/56509249/15372665
        Animation
            .easeInOut(duration: 1) // .easeIn, .easeOut, .linear, etc...
            .repeatForever()
    }

    var body: some View {
        ZStack {
            ARViewWrapper(alertViewText: $alertViewText, isShowingHelpView: $isShowingHelpView, tutorialStage: $tutorialStage)
            VStack {
                Spacer()
                    .frame(height: 10)
                HStack {
                    Spacer()

                    if alertViewText != "" {
                        Text(alertViewText)
                            .font(.title)
                            .foregroundColor(Color(hex: "#7b9acc"))
                            .padding()
                            .background {
                                RoundedRectangle(cornerRadius: 10)
                                    .foregroundColor(Color(hex: "#FCF6F5"))
                            }
                    }

                    Spacer()

                    if tutorialStage == 4 {
                        // Show arrow
                        Image(systemName: "arrow.right")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 50)
                            .foregroundColor(.accentColor)
                            .scaleEffect(size)
                            .onAppear {
                                // Animate arrow forever
                                withAnimation(self.repeatingAnimation) { self.size = 1.2 }
                            }
                    }

                    if tutorialStage > 3 {
                        Button(action: {
                            isShowingHelpView.toggle()
                            arView.showOrHideHelpView()
                        }, label: {
                            Image(systemName: "questionmark.circle.fill")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 50)
                                .foregroundColor(.primary)
                        })
                    }
                    Spacer()
                        .frame(width: 20)
                }
                Spacer()
            }

            if isShowingTutorialView {
                TutorialOverlayView()
                    // https://stackoverflow.com/a/58512696/15372665
                    .zIndex(2)
                    .onTapGesture {
                        withAnimation {
                            isShowingTutorialView.toggle()
                        }
                    }
            }
        }
    }
}
