//
//  File.swift
//  WWDC22
//
//  Created by Juha Park on 4/5/22.
//

import AVFoundation
import RealityKit
import SwiftUI

class FramedPhotoObject: CustomObject {
    var height: Float = 0.1
    var photoModel = ModelEntity()

    let photoNames: [String] = ["thumbnail4.png", "thumbnail2.png", "thumbnail3.png"]
    let videoNames: [String] = ["video4.mov", "video2.mov", "video3.mov"]
    var currentImageIndex = 0
    
    var videoIsPlaying = false

    public required init() {
        super.init()

        //Set up the image (thumbnail) and apply it as a texture
        let image: UIImage = UIImage(imageLiteralResourceName: photoNames[currentImageIndex])
        let aspectRatio: Float = Float(image.size.width / image.size.height)

        let frameModel = EntityManager().loadModel(usdzName: "photoFrame")

        var photoMaterial = SimpleMaterial()
        photoMaterial.color.texture = .init(try! .load(named: photoNames[currentImageIndex]))
        photoMaterial.metallic = MaterialScalarParameter(floatLiteral: 0.5)
        photoMaterial.roughness = MaterialScalarParameter(floatLiteral: 0.5)

        let photoMesh: MeshResource = .generatePlane(width: height * aspectRatio, depth: height)
        photoModel = ModelEntity(mesh: photoMesh, materials: [photoMaterial])

        photoModel.position.y = 0.045
        photoModel.position.z = -0.02
        photoModel.orientation = simd_quatf(angle: .pi / 3, axis: [1, 0, 0])

        frameModel.scale = [height * 10, height * 10, height * 10]
        frameModel.scale.x = height * 10 * aspectRatio

        frameModel.name = "Photo_Frame"
        photoModel.name = "Photo_Image"

        addChild(frameModel)
        addChild(photoModel)
        makeInfoView(text: "This is Photos. The image changes every 10 seconds and the frame adjusts to its size. Tap on any image to play a video and tap again to move to the next one.")
        infoViewModel.name = "Photo_InfoViewModel"
        infoViewText.name = "Photo_InfoViewText"
        infoViewWrapper.name = "Photo_InfoViewWrapper"

        generateCollisionShapes(recursive: true)
        startTimer()
    }

    // https://stackoverflow.com/a/64701285/15372665
    func getVideoAspectRatio(url: URL) -> CGFloat? {
        //Get the aspect ratio of a video
        guard let track = AVURLAsset(url: url).tracks(withMediaType: AVMediaType.video).first else { return nil }
        let size = track.naturalSize.applying(track.preferredTransform)
        return abs(size.height) / abs(size.width)
    }

    let player = AVPlayer()

    func playVideo(fileName: String) {
        // Play video
        // https://maxxfrazer.medium.com/realitykit-videomaterials-66ad05f396f4

        let videoURL = Bundle.main.url(forResource: fileName, withExtension: nil)!
        let videoAsset = AVURLAsset(url: videoURL)

        let playerItem = AVPlayerItem(asset: videoAsset)
        // Create a Material and assign it to your model entity
        photoModel.model?.materials = [VideoMaterial(avPlayer: player)]
        // Tell the player to load and play
        player.replaceCurrentItem(with: playerItem)
        player.play()

        // Loop video
        NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: player.currentItem, queue: .main) { _ in
            //Loop (play from start again)
            self.player.seek(to: CMTime.zero)
            self.player.play()
        }
    }
    
    func stopVideo() {
        //Stop the video and get the audio player ready for the next video
        //Pause player
        player.pause()
        //Reset player
        self.player.replaceCurrentItem(with: nil)
    }
    
    var timer = Timer()
    
    func changeImage() {
        //Change the image
        currentImageIndex = (currentImageIndex + 1) % photoNames.count

        photoModel.model?.materials.removeAll()

        // To use across all image formats
        var newAspectRatio: Float = 1

        let newImage = UIImage(imageLiteralResourceName: photoNames[currentImageIndex])
        newAspectRatio = Float(newImage.size.width / newImage.size.height)

        var newPhotoMaterial = SimpleMaterial()

        newPhotoMaterial.color.texture = .init(try! .load(named: photoNames[currentImageIndex]))
        newPhotoMaterial.metallic = MaterialScalarParameter(floatLiteral: 0.5)
        newPhotoMaterial.roughness = MaterialScalarParameter(floatLiteral: 0.5)

        photoModel.model?.materials = [newPhotoMaterial]

        // Resize the meshes to fit new aspect ratio
        let newPhotoMesh: MeshResource = .generatePlane(width: 0.1 * newAspectRatio, depth: 0.1)
        photoModel.model?.mesh = newPhotoMesh

        let frame = self.children[0]
        frame.scale.x = newAspectRatio
    }

    public func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 10.0, repeats: true) { [self] _ in
            //Change the image every 10 seconds (would probably be around 5-10mins in everyday life, like a screensaver or background)
            changeImage()
        }
    }
    
    public func hittest(tappedEntity: Entity) -> Bool {
        // Returns whether or not tapped entity was an interactive object in Photos

        if tappedEntity.name == "Photo_Image" || tappedEntity.name == "Photo_Frame" {
            //Tapped Photo
            if photoNames[currentImageIndex].contains("thumbnail") {
                if !videoIsPlaying {
                    // Play video
                    playVideo(fileName: videoNames[currentImageIndex])
                    videoIsPlaying = true
                    //Stop timer
                    //https://stackoverflow.com/a/31820777/15372665
                    timer.invalidate()
                } else {
                    // Stop video
                    stopVideo()
                    // Start timer again (move to next one)
                    timer = Timer.scheduledTimer(withTimeInterval: 10.0, repeats: true) { [self] _ in
                        changeImage()
                    }
                    timer.fire()
                    videoIsPlaying = false
                }
            }
            return true
        }
        return false
    }
}
