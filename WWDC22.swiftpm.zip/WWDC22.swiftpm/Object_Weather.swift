//
//  File.swift
//  WWDC22
//
//  Created by Juha Park on 4/5/22.
//

import Combine
import RealityKit
import SwiftUI

public enum WeatherCase: String, CaseIterable {
    case sunny, cloudy, snowy, stormy
}

public class WeatherObject: CustomObject {
    var object: WeatherCase = .sunny

    let detailViewWrap = ModelEntity()
    var detailViewPlane = ModelEntity()
    let minusModel = EntityManager().loadModel(usdzName: "minusButton") as! ModelEntity
    let plusModel = EntityManager().loadModel(usdzName: "plusButton") as! ModelEntity
    let plusMinusButton = EntityManager().loadModel(usdzName: "plusButton") as! ModelEntity
    
    var wrap = ModelEntity()
    
    var tempModel = ModelEntity()
    
    struct WeatherDetails {
        let date: String
        let temperature: String
        let rainChance: String
        let wind: String
        let humidity: String
    }
    
    let weatherDetailsList: [WeatherDetails] = [WeatherDetails(date: "Thu 4/14", temperature: "63.0°", rainChance: "Rain: 15%", wind: "Wind: 12mph", humidity: "Humidity: 44%"), WeatherDetails(date: "Sun 4/17", temperature: "57.6°", rainChance: "Rain: 16%", wind: "Wind: 20mph", humidity: "Humidity: 60%"), WeatherDetails(date: "Sat 2/5", temperature: "14.1°", rainChance: "Rain: 90%", wind: "Wind: 22mph", humidity: "Humidity: 73%"), WeatherDetails(date: "Mon 3/21", temperature: "48.0°", rainChance: "Rain: 100%", wind: "Wind: 21mph", humidity: "Humidity: 70%")]
    

    public required init(object: WeatherCase) {
        self.object = object
        super.init()
        let tempText = MeshResource.generateText("63.0°", extrusionDepth: 0.003, font: .systemFont(ofSize: 0.05, weight: .thin), containerFrame: .zero, alignment: .center, lineBreakMode: .byClipping)
        let tempMaterial = SimpleMaterial(color: .lightGray, roughness: 0.5, isMetallic: true)
        
        tempModel = ModelEntity(mesh: tempText, materials: [tempMaterial])


        tempModel.name = "Weather_TempModel"

        tempModel.position.y += 0.05
        tempModel.position.z += 0.02
        tempModel.position.x += 0.02

        let stand = EntityManager().loadModel(usdzName: "stand")
        stand.name = "Weather_Stand"

        //Add different models for weather
        if object == .sunny {
            let sun = EntityManager().loadModel(usdzName: "sun")
            sun.name = "Weather_Sun"
            wrap.name = "Weather_Wrap"

            wrap.addChild(sun)
            sun.position.y += 0.2
            addChild(wrap)

        } else if object == .cloudy {
            let cloud = EntityManager().loadModel(usdzName: "cloud")

            cloud.name = "Weather_Cloud"
            wrap.name = "Weather_Wrap"

            wrap.addChild(cloud)

            cloud.position.y += 0.15
            cloud.scale = SIMD3<Float>(0.8, 0.8, 0.8)
            addChild(wrap)

        } else if object == .snowy {
            let snowCloud = EntityManager().loadModel(usdzName: "snow")
            let snow2 = EntityManager().loadModel(usdzName: "snow2")

            snowCloud.name = "Weather_SnowCloud"
            snow2.name = "Weather_Snow2"
            wrap.name = "Weather_Wrap"

            wrap.addChild(snowCloud)
            wrap.addChild(snow2)

            snowCloud.position.y += 0.1
            snowCloud.scale = SIMD3<Float>(0.8, 0.8, 0.8)
            snow2.position.y += 0.1
            snow2.scale = SIMD3<Float>(0.8, 0.8, 0.8)

            snow2.isEnabled = false

            addChild(wrap)

        } else if object == .stormy {
            let stormCloud = EntityManager().loadModel(usdzName: "storm1")
            let storm2 = EntityManager().loadModel(usdzName: "storm2")

            stormCloud.name = "Weather_StormCloud"
            storm2.name = "Weather_Storm2"
            wrap.name = "Weather_Wrap"

            wrap.addChild(stormCloud)
            wrap.addChild(storm2)

            stormCloud.position.y += 0.1
            stormCloud.scale = SIMD3<Float>(0.8, 0.8, 0.8)
            storm2.position.y += 0.1
            storm2.scale = SIMD3<Float>(0.8, 0.8, 0.8)

            storm2.isEnabled = false

            addChild(wrap)
        } else {
            let mesh = MeshResource.generateSphere(radius: 0.1)
            let material = SimpleMaterial(color: .green, isMetallic: false)
            addChild(ModelEntity(mesh: mesh, materials: [material]))
        }
        
        addChild(stand)

        addChild(tempModel)
        
        
        // Detailed view
        let height: Float = 0.25
        let dateTimeText = textEntityWithName(text: weatherDetailsList[0].date)
        let rainChanceText = textEntityWithName(text: weatherDetailsList[0].rainChance)
        let windText = textEntityWithName(text: weatherDetailsList[0].wind)
        let humidityText = textEntityWithName(text: weatherDetailsList[0].humidity)

        dateTimeText.name = "Weather_DateTimeText"
        rainChanceText.name = "Weather_RainChanceText"
        windText.name = "Weather_WindText"
        humidityText.name = "Weather_HumidityText"

        dateTimeText.position.y = height
        rainChanceText.position.y = height - 0.05
        windText.position.y = height - 0.08
        humidityText.position.y = height - 0.11

        dateTimeText.position.x = 0.13
        rainChanceText.position.x = 0.13
        windText.position.x = 0.13
        humidityText.position.x = 0.13

        detailViewWrap.addChild(dateTimeText)
        detailViewWrap.addChild(rainChanceText)
        detailViewWrap.addChild(windText)
        detailViewWrap.addChild(humidityText)

        // https://stackoverflow.com/a/59117633/15372665
        var material = SimpleMaterial()
        material.color = .init(tint: UIColor(red: 0.00, green: 0.33, blue: 0.61, alpha: 0.6), texture: nil)

        detailViewPlane = ModelEntity(mesh: MeshResource.generatePlane(width: 0.13, height: 0.15), materials: [material])
        detailViewPlane.position.y = height / 2
        detailViewPlane.position.x = 0.11

        plusMinusButton.position.y = 0.04
        plusMinusButton.position.x = -0.02
        plusMinusButton.position.z = 0.02

        plusMinusButton.name = "Weather_PlusButton"
        detailViewPlane.name = "Weather_DetailViewPlane"
        detailViewWrap.name = "Weather_DetailViewWrap"

        addChild(detailViewWrap)
        addChild(detailViewPlane)
        addChild(plusMinusButton)
        
        makeInfoView(text: "This is Weather. It changes every 15 seconds (usually it would update live). Tap on the plus button to view additional details about the current weather.")
        infoViewModel.name = "Weather_InfoViewModel"
        infoViewText.name = "Weather_InfoViewText"
        infoViewWrapper.name = "Weather_InfoViewWrapper"

        for child in children {
            child.scale = [0.6, 0.6, 0.6]
        }
        generateCollisionShapes(recursive: true)

        detailViewWrap.isEnabled = false
        detailViewPlane.isEnabled = false
    }

    required init() {
        fatalError("init() has not been implemented")
    }

    var yPositions: [Float] = []
    var first = true

    var isShowingDetails = false
    
    func animateEntryDetailView() {
        children[3].isEnabled = true
        detailViewPlane.isEnabled = true
        
        isShowingDetails = true
        
        var scale: Float = 0.02
        children[3].scale = [scale, scale, scale]
        detailViewPlane.scale = [scale, scale, scale]
        
        Timer.scheduledTimer(withTimeInterval: 0.005, repeats: true) { timer in

            if scale >= 0.6 {
                timer.invalidate()
                return
            }
            scale += 0.02
            
            self.children[3].scale = [scale, scale, scale]
            self.detailViewPlane.scale = [scale, scale, scale]
        }
    }

    func animateExitDetailView() {
        children[3].isEnabled = true
        detailViewPlane.isEnabled = true
        
        isShowingDetails = false
        
        var scale: Float = 0.6
        children[3].scale = [scale, scale, scale]
        detailViewPlane.scale = [scale, scale, scale]
        
        Timer.scheduledTimer(withTimeInterval: 0.005, repeats: true) { timer in

            if scale <= 0.02 {
                timer.invalidate()
                return
            }
            scale -= 0.02
            
            self.children[3].scale = [scale, scale, scale]
            self.detailViewPlane.scale = [scale, scale, scale]
        }
    }
    
    var animationTimer = Timer()
    
    public func changeModel(to: WeatherCase) {
        stopAnimation()
        let newWrap = ModelEntity()
        switch to {
        case .sunny:
            let sun = EntityManager().loadModel(usdzName: "sun")

            sun.name = "Weather_Sun"
            wrap.name = "Weather_Wrap"

            newWrap.addChild(sun)
            sun.position.y += 0.2
        case .cloudy:
            let cloud = EntityManager().loadModel(usdzName: "cloud")

            cloud.name = "Weather_Cloud"

            newWrap.addChild(cloud)

            cloud.position.y += 0.15
            cloud.scale = SIMD3<Float>(0.8, 0.8, 0.8)
        case .snowy:
            let snowCloud = EntityManager().loadModel(usdzName: "snow")
            let snow2 = EntityManager().loadModel(usdzName: "snow2")

            snowCloud.name = "Weather_SnowCloud"
            snow2.name = "Weather_Snow2"

            newWrap.addChild(snowCloud)
            newWrap.addChild(snow2)

            snowCloud.position.y += 0.1
            snowCloud.scale = SIMD3<Float>(0.8, 0.8, 0.8)
            snow2.position.y += 0.1
            snow2.scale = SIMD3<Float>(0.8, 0.8, 0.8)

            snow2.isEnabled = false

        case .stormy:
            let stormCloud = EntityManager().loadModel(usdzName: "storm1")
            let storm2 = EntityManager().loadModel(usdzName: "storm2")

            stormCloud.name = "Weather_StormCloud"
            storm2.name = "Weather_Storm2"

            newWrap.addChild(stormCloud)
            newWrap.addChild(storm2)

            stormCloud.position.y += 0.1
            stormCloud.scale = SIMD3<Float>(0.8, 0.8, 0.8)
            storm2.position.y += 0.1
            storm2.scale = SIMD3<Float>(0.8, 0.8, 0.8)

            storm2.isEnabled = false
        }
        
        newWrap.scale = [0.6, 0.6, 0.6]
        newWrap.name = "Weather_Wrap"
        wrap.name = "Weather_Wrap"
        children[0] = newWrap
        animate(object: to)
        
        // Change Details / Temperature
        let newIndex = WeatherCase.allCases.firstIndex(of: to)!
        let newDateTimeText = textEntityWithName(text: weatherDetailsList[newIndex].date)
        let newRainChanceText = textEntityWithName(text: weatherDetailsList[newIndex].rainChance)
        let newWindText = textEntityWithName(text: weatherDetailsList[newIndex].wind)
        let newHumidityText = textEntityWithName(text: weatherDetailsList[newIndex].humidity)
        
        let previousScale = children[3].scale
        let wasEnabled = children[3].isEnabled
        
        newDateTimeText.position.y = 0.25
        newRainChanceText.position.y = 0.2
        newWindText.position.y = 0.17
        newHumidityText.position.y = 0.14

        newDateTimeText.position.x = 0.13
        newRainChanceText.position.x = 0.13
        newWindText.position.x = 0.13
        newHumidityText.position.x = 0.13

        let newDetailViewWrap = ModelEntity()
        newDetailViewWrap.addChild(newDateTimeText)
        newDetailViewWrap.addChild(newRainChanceText)
        newDetailViewWrap.addChild(newWindText)
        newDetailViewWrap.addChild(newHumidityText)
        children[3] = newDetailViewWrap
        if wasEnabled {
            children[3].scale = previousScale
        } else {
            children[3].scale = [0.0005, 0.0005, 0.0005]
        }
        
        //Temperature view
        let newTempText = MeshResource.generateText(weatherDetailsList[newIndex].temperature, extrusionDepth: 0.003, font: .systemFont(ofSize: 0.05, weight: .thin), containerFrame: .zero, alignment: .center, lineBreakMode: .byClipping)
        tempModel.model?.mesh = newTempText
        
        self.generateCollisionShapes(recursive: true)
    }
    
    public func stopAnimation() {
        stopAllAnimations(recursive: true)
        animationTimer.invalidate()
    }
        
    public func animate(object: WeatherCase) {
        switch object {
        case .sunny:
            // animate sun
            let rotation = Transform(pitch: 0, yaw: 0, roll: .pi)

            children[0].children[0].orientation = rotation.rotation

            var animUpdateSubscription: Cancellable?

            func animateLoop() {
                children[0].children[0].move(to: rotation, relativeTo: children[0].children[0], duration: 5.0, timingFunction: .linear)

                guard animUpdateSubscription == nil else { return }

                animUpdateSubscription = scene!.subscribe(to: AnimationEvents.PlaybackCompleted.self, on: children[0].children[0], { _ in
                    animateLoop()
                })
            }

            animateLoop()
        case .cloudy:
            // animate cloud
            var up = true
            animationTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
                // move up or down
                if up {
                    self.children[0].children[0].position.y += 0.01
                    up = false
                } else {
                    self.children[0].children[0].position.y -= 0.01
                    up = true
                }
            }
            break
        case .snowy:
            // animate snow
            let snow1 = children[0].children[0]
            let snow2 = children[0].children[1]

            snow1.isEnabled = true
            snow2.isEnabled = false

            animationTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
                snow1.isEnabled.toggle()
                snow2.isEnabled.toggle()
            }
        case .stormy:
            // animate storm
            let storm1 = children[0].children[0]
            let storm2 = children[0].children[1]

            storm1.isEnabled = true
            storm2.isEnabled = false

            animationTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
                storm1.isEnabled.toggle()
                storm2.isEnabled.toggle()
            }
        }
    }

    public func hittest(tappedEntity: Entity) -> Bool {
        // Returns whether or not tapped entity was an interactive object in Weather

        if tappedEntity.name == "Weather_PlusButton" {
            // Tapped plus button (expand detailed view)
            animateEntryDetailView()
            plusMinusButton.model = minusModel.model
            plusMinusButton.name = "Weather_MinusButton"
            return true
        } else if tappedEntity.name == "Weather_MinusButton" {
            // Tapped minus button (hide detailed view)
            animateExitDetailView()
            plusMinusButton.model = plusModel.model
            plusMinusButton.name = "Weather_PlusButton"
            return true
        }
        return false
    }
}
